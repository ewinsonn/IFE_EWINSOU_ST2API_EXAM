namespace DE_EWINSOU_IFE;

public class Exercise4
{
    public static void Game()
    {
        string i = "";
        int cmp = 0;
        int cmp1 = 0;
         while (i != "NO")
         {
             string[] choices = new string[3] { "ROCK", "PAPER", "SCISSOR" };
                Random rnd = new Random();
                int n = rnd.Next(0, 3);
                Console.WriteLine("Enter your choice:");
                string user = Console.ReadLine().ToUpper();
                Console.WriteLine("Computer:" + choices[n]);

                if (user == "ROCK" && choices[n] == "SCISSOR")
                {
                    Console.WriteLine("User wins");
                    cmp += 1;
                }
                else if (user == "ROCK" && choices[n] == "PAPER")
                {
                    Console.WriteLine("Computer wins");
                    cmp1 += 1;
                }
                else if (user == "PAPER" && choices[n] == "ROCK")
                {
                    Console.WriteLine("User wins");
                    cmp += 1;
                }
                else if (user == "PAPER" && choices[n] == "SCISSOR")
                {
                    Console.WriteLine("Computer Wins");
                    cmp1 += 1;
                }
                else if (user == "SCISSOR" && choices[n] == "ROCK")
                {
                    Console.WriteLine("Computer Wins ;)");
                    cmp1 += 1;
                }
                else if (user == "SCISSOR" && choices[n] == "PAPER")
                {
                    Console.WriteLine("----------YOU  WIN :)------------ ");
                    cmp += 1;
                }
                else
                {
                    Console.WriteLine("Same choices");
                }
                Console.WriteLine("Do You want to continue(YES/NO):");
                i = Console.ReadLine().ToUpper();
                Console.WriteLine("---------------------------------------");
         }
         Console.WriteLine("User wins " + cmp + " times");
         Console.WriteLine("Computer wins " + cmp1+ " times");
        }
    }
    