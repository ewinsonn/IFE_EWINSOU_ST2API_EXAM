namespace DE_EWINSOU_IFE;

public class Exercise1
{
    
    public static void DisplayArmstrong()
    {
        for (int i = 100; i < 1000; i++)
        {
            int j = i;
            double sum = 0;
            while (j > 0)
            {
                sum += Math.Pow(j % 10, 3);
                j /= 10;
            }

            if (i == (int)sum)
            {
                Console.WriteLine(i);
            }
        }
    }
    
}