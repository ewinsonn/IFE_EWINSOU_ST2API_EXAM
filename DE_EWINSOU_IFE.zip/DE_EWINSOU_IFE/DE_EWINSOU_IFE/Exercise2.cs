namespace DE_EWINSOU_IFE;

public class Exercise2
{
    public static void gameNumber()
    {
        Random rand = new Random();
        int number = rand.Next(0, 101);
        while (true)
        {
            int cmp = 1;
            while (true)
            {
                Console.Write("Enter a number between 1 and 100 (0 to quit):");
                int findN = Convert.ToInt32(Console.ReadLine());
                if (findN == 0)
                    return;
                else if (findN < number)
                {
                    Console.WriteLine("The Number is greater than your number;) try again  .");
                    ++cmp;
                    continue;
                }
                else if (findN > number)
                {
                    Console.WriteLine("The number is lower that your number ;) , try agan  ");
                    ++cmp;
                    continue;
                }
                else
                {
                    Console.WriteLine("Congrats :) ! The number was {0}!",
                        number);
                    break;
                }
            }

        }

    }
}
    