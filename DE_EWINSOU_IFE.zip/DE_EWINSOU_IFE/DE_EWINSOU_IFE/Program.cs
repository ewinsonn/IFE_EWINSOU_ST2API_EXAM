﻿using System;

namespace DE_EWINSOU_IFE
{

    class Program
    {
        private static int AskUserForParamater()
        {
            Console.WriteLine("Please write a number and press enter :");
            int.TryParse(Console.ReadLine(), out var result);
            return result;
        }

        public static void Main(string[] args)
        {
            Console.WriteLine("               START ST2API EXAM            ");
            Console.WriteLine();
            int rep = 0;
            do
            {
                bool current = true;
                do
                {
                    if (!current)
                    {
                        Console.WriteLine("Try again ! ");
                    }
                    Console.WriteLine("1- Armstrong's numbers ");
                    Console.WriteLine("2- More or Less ");
                    Console.WriteLine("3- Tic-Tac-Toe ");
                    Console.WriteLine("4- Rock Paper Scissor ");
                    

                    rep = AskUserForParamater();

                    if (rep == 1)
                    {
                        Console.WriteLine();
                        Console.WriteLine("Which is the Number that you want display the multiplication table");
                        Exercise1.DisplayArmstrong();
                    }
                    else if(rep==2){
                        Console.WriteLine();
                        Exercise2.gameNumber();
                    }
                    else if (rep == 3)
                    {
                        Console.WriteLine();
                        Exercise3.DrawBoard();
                    }
                    else if (rep == 4)
                    {
                        Console.WriteLine("WELCOME TO THE ROCK PAPER SCISSOR");
                        Console.WriteLine("PRESS 1 FOR ROCK");
                        Console.WriteLine("PRESS 2 FOR PAPER ");
                        Console.WriteLine("PRESS 3 FOR SCISSOR");
                        
                        
                        Exercise4.Game();   
                    }



                    else
                    {
                        current = false;
                    }
                }while (rep <= 0 || rep > 7);

                Console.WriteLine();
                Console.Write("Continous ... ");Console.ReadLine();
                Console.Clear();
            }while (rep != 6);

        }
    }
}